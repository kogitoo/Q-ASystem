package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TeachesDAO extends BaseDao{
    //通过教师名获取其所交课程名列表
    public ArrayList<CourseBean> selectAllCname_Tname(String tname){
        ArrayList<CourseBean> courseList=new ArrayList<CourseBean>();
        String sql="SELECT cname FROM teaches WHERE tname=\""+tname+"\"";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                CourseBean course=new CourseBean();
                course.setName(rs.getString("cname"));
                courseList.add(course);
            }
            rs.close();
            ps.close();
            conn.close();
            return courseList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //获取全部授课信息列表
    public ArrayList<TeachesBean> selectAllTeaches(){
        ArrayList<TeachesBean> teachesList=new ArrayList<TeachesBean>();
        String sql="SELECT * FROM teaches ";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                TeachesBean teaches=new TeachesBean();
                teaches.setTsid(rs.getString("tcid"));
                teaches.setCname(rs.getString("cname"));
                teaches.setTname(rs.getString("tname"));
                teachesList.add(teaches);
            }
            rs.close();
            ps.close();
            conn.close();
            return teachesList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //删除一条授课记录
    public boolean deleteTeaches(String tcid){
        String sql="DELETE FROM teaches WHERE tcid="+tcid;
        return executePs(sql);
    }

    //检查是否已经存在该授课记录
    public boolean ifTeachesExists(TeachesBean teaches){
        ArrayList<TeachesBean> teachesList=new ArrayList<TeachesBean>();
        String sql="SELECT * FROM teaches where tname=\""+teaches.getTname()+"\"";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                TeachesBean getTeaches=new TeachesBean();
                getTeaches.setCname(rs.getString("cname"));
                teachesList.add(getTeaches);
            }
            rs.close();
            ps.close();
            conn.close();

            boolean ifCnameExists=false;
            //遍历该教师教授的课程名
            for(int i=0;i<teachesList.size();i++){
                if(teaches.getCname().equals(teachesList.get(i).getCname())){
                    ifCnameExists=true;
                }
            }
            return ifCnameExists;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return false;
        }
    }

    //添加一条授课记录
    public boolean addTeaches(TeachesBean teaches){
        String sql="INSERT INTO teaches(tname,cname) VALUES(?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,teaches.getTname());
            ps.setString(2,teaches.getCname());
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
