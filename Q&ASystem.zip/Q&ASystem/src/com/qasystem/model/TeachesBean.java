package com.qasystem.model;

public class TeachesBean {
    private String tcid;
    private String tname;
    private String cname;

    public String getTcid() {
        return tcid;
    }

    public void setTsid(String tcid) {
        this.tcid = tcid;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
}
