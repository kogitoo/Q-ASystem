package com.qasystem.model;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

public class BaseDao implements Serializable {
    DataSource ds;
    Connection conn = null;

    //在构造方法中返回数据源对象
    public BaseDao() {
        try {
            Context context = new InitialContext();
            ds = (DataSource) context.lookup("java:comp/env/jdbc/mysql");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ds连接出错" + e.toString());
        }
    }

    //判断一个对象是否存在
    public boolean ifExists(Boolean sthExists, String sql, Connection connection) {
        try {
            Connection conn= connection;
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                sthExists=true;
            }
            rs.close();
            ps.close();
            conn.close();
            return sthExists;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return sthExists;
        }
    }

    //返回一个连接对象
    public Connection getCollection() throws Exception{
        try {
            this.conn=ds.getConnection();
        } catch (SQLException e) {
            System.out.println("ERR:"+e.toString());
        }
        return conn;
    }

    //执行一句sql语句，返回是否成功执行
    public boolean executePs(String sql){
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //验证用户身份
    public boolean checkIdentity(String sql, Connection connection, String name, String password) {
        try {
            Connection conn= connection;
            String truePassword=null;
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet rs= ps.executeQuery();
            if(rs.next()){
                truePassword=rs.getString("password");
                if(truePassword.equals(password)){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        } catch (SQLException e) {
            return false;
        }
    }

    //关闭资源
    public void close(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
