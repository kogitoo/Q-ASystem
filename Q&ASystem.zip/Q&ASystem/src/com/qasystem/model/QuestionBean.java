package com.qasystem.model;

public class QuestionBean {
    private String qid;
    private String title;
    private String content;
    private String sender;
    private String sendtime;
    private String answerExists;
    private String course;

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSendtime() {
        return sendtime;
    }

    public void setSendtime(String sendtime) {
        this.sendtime = sendtime;
    }

    public String getAnswerExists() {
        return answerExists;
    }

    public void setAnswerExists(String answerExists) {
        this.answerExists = answerExists;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}
