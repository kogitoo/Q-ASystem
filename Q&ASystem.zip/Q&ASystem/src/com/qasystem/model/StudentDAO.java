package com.qasystem.model;

import  com.qasystem.model.BaseDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StudentDAO extends BaseDao{
    public boolean insertStudent(StudentBean stu){
        String sql="INSERT INTO student(name,password) VALUES(?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,stu.getName());
            ps.setString(2,stu.getPassword());
            ps.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //验证学生账户信息
    public boolean checkStudent(StudentBean stu){
        String sql="SELECT password FROM student WHERE name=?";
        String name=stu.getName();
        String pswd=stu.getPassword();
        try {
            return checkIdentity(sql,ds.getConnection(),name,pswd);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //检查是否存在同名学生
    public boolean ifStudentExists(String name){
        Boolean studentExists=false;
        String sql="SELECT * FROM student WHERE name=\""+name+"\"";
        try {
            return ifExists(studentExists, sql, ds.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //重置密码
    public boolean resetPassword(String name,String password){
        String sql="UPDATE student set password=\""+password+
                "\"WHERE name=\""+name+"\"";
        return executePs(sql);
    }
}
