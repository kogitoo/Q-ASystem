package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TeacherDAO extends BaseDao {
    public boolean checkTeacher(TeacherBean teacher){
        String sql="SELECT password FROM teacher WHERE name=?";
        String name=teacher.getName();
        String pswd=teacher.getPassword();
        try {
            return checkIdentity(sql,ds.getConnection(),name,pswd);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //添加一条教师信息
    public boolean addTeacher(TeacherBean teacher){
        String sql="INSERT INTO teacher(name,password,title,info) VALUES(?,\"123\",?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,teacher.getName());
            ps.setString(2,teacher.getTitle());
            ps.setString(3,teacher.getInfo());
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //添加课程列表至教师信息
    public boolean addCourseForTeacher(TeacherBean teacher,int i){
        String sql="INSERT INTO teaches(cname,tname) VALUES(?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,teacher.getCourseList().get(i));
            ps.setString(2,teacher.getName());
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //根据教师姓名搜索教师表中是否有该教师记录
    public boolean ifTeacherExists(String name){
        Boolean teacherexists=false;
        String sql="SELECT * FROM teacher WHERE name=\""+name+"\"";
        try {
            return ifExists(teacherexists, sql, ds.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //删除一条教师信息
    public boolean deleteTeacher(TeacherBean teacher){
        String sql="DELETE FROM teacher WHERE name=\""+teacher.getName()+"\"";
        return executePs(sql);
    }

    //删除该教师的所有授课信息
    public boolean deleteCourseForTeacher(TeacherBean teacher){
        String sql="DELETE FROM teaches WHERE tname=\""+teacher.getName()+"\"";
        return executePs(sql);
    }

    //修改一条教师信息
    public boolean updateTeacher(TeacherBean teacher){
        String sql="UPDATE teacher set title=\""+teacher.getTitle()+
                "\",info=\""+teacher.getInfo()+
                "\"WHERE name=\""+teacher.getName()+"\"";
        return executePs(sql);
    }

    //查询所有教师信息
    public ArrayList<TeacherBean> selectAllTeacher(){
        ArrayList<TeacherBean> teacherList=new ArrayList<TeacherBean>();
        String sql="SELECT * FROM teacher";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                TeacherBean teacher= new TeacherBean();
                teacher.setName(rs.getString("name"));
                teacher.setPassword(rs.getString("password"));
                teacher.setTitle(rs.getString("title"));
                teacher.setInfo(rs.getString("info"));
                teacherList.add(teacher);
            }
            rs.close();
            ps.close();
            conn.close();
            return teacherList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //获取单个教师信息
    public TeacherBean selectOneTeacher(String name){
        String sql="SELECT * FROM teacher where name=\""+name+"\"";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            TeacherBean teacher=new TeacherBean();
            while(rs.next()){
                teacher.setName(rs.getString("name"));
                teacher.setTitle(rs.getString("title"));
                teacher.setInfo(rs.getString("info"));
            }
            rs.close();
            ps.close();
            conn.close();
            return teacher;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //查询教师授课信息
    public ArrayList<TeacherBean> selectCourseForTeacher(ArrayList<TeacherBean> teacherList){
        Connection conn;
        PreparedStatement ps;
        ResultSet rs;
        //遍历老师列表
        for (int i = 0; i < teacherList.size(); i++) {
            String sql="SELECT cname From teaches WHERE tname=\""+teacherList.get(i).getName()+"\"";
            ArrayList<String> cList=new ArrayList<String>();
            try {
                conn=ds.getConnection();
                ps=conn.prepareStatement(sql);
                rs=ps.executeQuery();
                while(rs.next()){
                    String course=rs.getString("cname");
                    cList.add(course);
                }
                rs.close();
                ps.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println(e.toString());
                continue;
            }
            teacherList.get(i).setCourseList(cList);
        }

        return teacherList;
    }

    //重置密码
    public boolean resetPassword(String name,String password){
        String sql="UPDATE teacher set password=\""+password+
                "\"WHERE name=\""+name+"\"";
        return executePs(sql);
    }

}
