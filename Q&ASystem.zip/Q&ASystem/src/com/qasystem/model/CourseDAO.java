package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseDAO extends BaseDao {
    //通过学院名查询课程
    public ArrayList<CourseBean> selectAllCourse_Dept(String deptName){
        ArrayList<CourseBean> courseList=new ArrayList<CourseBean>();
        String sql="SELECT * FROM course WHERE dept=\""+deptName+"\"";
        return selectCourse(courseList, sql);
    }

    //查询全部课程信息
    public ArrayList<CourseBean> selectAllCourse(){
        ArrayList<CourseBean> courseList=new ArrayList<CourseBean>();
        String sql="SELECT * FROM course ";
        return selectCourse(courseList, sql);
    }

    //通过课程名查询课程
    public ArrayList<CourseBean> selectCourse_cName(String cName){
        ArrayList<CourseBean> courseList=new ArrayList<CourseBean>();
        String sql="SELECT * FROM course WHERE name=\""+cName+"\"";
        return selectCourse(courseList, sql);
    }

    //通过课程名查找该课程是否已经存在
    public boolean ifCourseExists(String name){
        Boolean courseExists=false;
        String sql="SELECT * FROM course WHERE name=\""+name+"\"";
        try {
            return ifExists(courseExists, sql, ds.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //添加一门课程信息
    public boolean addCourse(CourseBean course){
        String sql="INSERT INTO course(name,dept,info) VALUES(?,?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,course.getName());
            ps.setString(2,course.getDept());
            ps.setString(3,course.getInfo());
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //删除一条课程信息
    public boolean deleteCourse(CourseBean course){
        String sql="DELETE FROM course WHERE name=\""+course.getName()+"\"";
        return executePs(sql);
    }

    //修改一门课程信息
    public boolean updateCourse(CourseBean course){
        String sql="UPDATE course set dept=\""+course.getDept()+
                "\",info=\""+course.getInfo()+
                "\"WHERE name=\""+course.getName()+"\"";
        return executePs(sql);
    }

    //通过课程名列表获取课程列表
    public ArrayList<CourseBean> selectCourse_cnameList(ArrayList<CourseBean> cnameList){
        ArrayList<CourseBean> courseList=new ArrayList<CourseBean>();
        for(int i=0;i<cnameList.size();i++){
            String sql="SELECT * FROM course WHERE name=\""+cnameList.get(i).getName()+"\"";
            try {
                Connection conn=ds.getConnection();
                PreparedStatement ps=conn.prepareStatement(sql);
                ResultSet rs=ps.executeQuery();
                courseList=getCourse(courseList, rs);
                rs.close();
                ps.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("error:"+e.toString());
            }
        }
        return courseList;

    }

    //遍历resultset获取课程信息
    private ArrayList<CourseBean> getCourse(ArrayList<CourseBean> courseList, ResultSet rs) throws SQLException {
        while(rs.next()){
            CourseBean course=new CourseBean();
            course.setName(rs.getString("name"));
            course.setDept(rs.getString("dept"));
            course.setInfo(rs.getString("info"));
            courseList.add(course);
        }
        return courseList;
    }

//    建立连接，创建预备语句以及结果集
    private ArrayList<CourseBean> selectCourse(ArrayList<CourseBean> courseList, String sql) {
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            courseList=getCourse(courseList, rs);
            rs.close();
            ps.close();
            conn.close();
            return courseList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }
}
