package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class QuestionDAO extends BaseDao{
    //根据课程名查询所有留言信息
    public ArrayList<QuestionBean> selectAllQuestion_Course(String courseName){
    ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
        String sql="SELECT * FROM question WHERE course=\""+courseName+"\"";
        return selectQuestion(questionList, sql);
    }

    //根据课程名查询所有尚未回答的新留言信息
    public ArrayList<QuestionBean> selectAllNewQuestion_Course(String courseName){
        ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
        String sql="SELECT * FROM question WHERE course=\""+courseName+"\" and answerExists=\"false\"";
        return selectQuestion(questionList, sql);
    }

    //根据留言编号查询该留言信息
    public ArrayList<QuestionBean> selectAllQuestion_Qid(String qid){
        ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
        String sql="SELECT * FROM question WHERE qid=\""+qid+"\"";
        return selectQuestion(questionList, sql);
    }

    //根据发送人查询其所有问题留言
    public ArrayList<QuestionBean> selectAllQuestion_Sender(String sender){
        ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
        String sql="SELECT * FROM question WHERE sender=\""+sender+"\"";
        return selectQuestion(questionList, sql);
    }

    //模糊搜索，返回问题集
    public ArrayList<QuestionBean> search(String keyword,String scope){
        ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
        String sql="SELECT * FROM question WHERE "+scope+" like\"%"+keyword+"%\"";
        System.out.println(sql);
        return selectQuestion(questionList, sql);
    }

    //添加一条留言信息
    public boolean addQuestion(QuestionBean question){
        String sql="INSERT INTO question(title,content,sender,sendtime,answerExists,course) VALUES(?,?,?,?,\"false\",?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,question.getTitle());
            ps.setString(2,question.getContent());
            ps.setString(3,question.getSender());
            ps.setString(4,question.getSendtime());
            ps.setString(5,question.getCourse());
            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //修改一条留言信息
    public boolean updateQuestion(QuestionBean question){
        String sql="update question set title=\""+question.getTitle()+
                "\",course=\""+question.getCourse()+
                "\", content=\""+question.getContent()+
                "\",sender =\""+question.getSender()+
                "\",sendtime=\""+question.getSendtime()+
                "\" WHERE qid="+question.getQid();
        System.out.println(sql);
        return executePs(sql);
    }

    //删除一条留言信息
    public boolean deleteQuestion(String qid){
        String sql="DELETE FROM question WHERE qid="+qid;
        return executePs(sql);
    }

//   教师 根据课程名，返回该课程中未回复的消息数量
    public int getNewQuestionNum(String courseName){
        String sql="SELECT * FROM question WHERE course=\""+courseName+"\" and answerExists=\"false\"";
        return getQuestionNum(sql);
    }


//    学生 根据学生姓名，返回该课程中回复了的消息数量
public int stuGetAEQuestionNum(String name){
    String sql="SELECT * FROM question WHERE sender=\""+name+"\" and answerExists=\"true\"";
    return getQuestionNum(sql);
}

    private int getQuestionNum(String sql) {
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            int newQuestionNum=0;
            while(rs.next()){
                newQuestionNum++;
            }
            rs.close();
            ps.close();
            conn.close();
            return newQuestionNum;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return 0;
        }
    }

    //根据sql语句查询留言语句，并返回留言信息列表
    private ArrayList<QuestionBean> selectQuestion(ArrayList<QuestionBean> questionList, String sql) {
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                QuestionBean question=new QuestionBean();
                question.setQid(rs.getString("qid"));
                question.setTitle(rs.getString("title"));
                question.setContent(rs.getString("content"));
                question.setSender(rs.getString("sender"));
                question.setSendtime(rs.getString("sendtime"));
                question.setAnswerExists(rs.getString("answerExists"));
                question.setCourse(rs.getString("course"));
                questionList.add(question);
            }
            rs.close();
            ps.close();
            conn.close();
            return questionList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }
}
