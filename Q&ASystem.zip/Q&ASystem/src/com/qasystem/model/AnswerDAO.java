package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AnswerDAO extends BaseDao {
    //根据留言id查询所有答复信息
    public ArrayList<AnswerBean> selectAllAnswer_Question(String qid){
        ArrayList<AnswerBean> answerList=new ArrayList<AnswerBean>();
        String sql="SELECT * FROM answer WHERE qid=\""+qid+"\"";
        return getAnswerList(answerList, sql);
    }

    //根据课程名获取所有答复信息
    public ArrayList<AnswerBean> selectAllAnswer_Course(String course){
        ArrayList<AnswerBean> answerList=new ArrayList<AnswerBean>();
        String sql="SELECT * FROM answer WHERE course=\""+course+"\"";
        return getAnswerList(answerList, sql);
    }

    //根据课教师姓名获取所有答复信息
    public ArrayList<AnswerBean> selectAllAnswer_Sender(String sender){
        ArrayList<AnswerBean> answerList=new ArrayList<AnswerBean>();
        String sql="SELECT * FROM answer WHERE sender=\""+sender+"\"";
        return getAnswerList(answerList, sql);
    }

    //根据回答号获得该答复信息
    public AnswerBean selectOneAnswer(String aid){
        ArrayList<AnswerBean> answerList=new ArrayList<AnswerBean>();
        ArrayList<AnswerBean> newanswerList=new ArrayList<AnswerBean>();
        String sql="SELECT * FROM answer WHERE aid="+aid;
        newanswerList=(ArrayList<AnswerBean>)getAnswerList(answerList, sql).clone();
        AnswerBean answer=newanswerList.get(0);
        return answer;
    }


    private ArrayList<AnswerBean> getAnswerList(ArrayList<AnswerBean> answerList, String sql) {
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                AnswerBean answer=new AnswerBean();
                answer.setAid(rs.getString("aid"));
                answer.setQid(rs.getString("qid"));
                answer.setCourse(rs.getString("course"));
                answer.setTitle(rs.getString("title"));
                answer.setContent(rs.getString("content"));
                answer.setSendtime(rs.getString("sendtime"));
                answer.setSender(rs.getString("sender"));
                answerList.add(answer);
            }
            rs.close();
            ps.close();
            conn.close();
            return answerList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //添加一条回答信息
    public boolean addAnswer(AnswerBean answer) {
        String sql = "INSERT INTO answer(qid,course,title,content,sender,sendtime) VALUES(?,?,?,?,?,?)";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ps.setString(1,answer.getQid());
            ps.setString(2,answer.getCourse());
            ps.setString(3,answer.getTitle());
            ps.setString(4,answer.getContent());
            ps.setString(5,answer.getSender());
            ps.setString(6,answer.getSendtime());

            ps.execute();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //删除一条回答信息
    public boolean deleteAnswer(String aid){
        String sql="DELETE FROM answer WHERE aid="+aid;
        return executePs(sql);
    }

    //修改一条留言信息
    public boolean updateAnswer(AnswerBean answer){
        String sql="update answer set title=\""+answer.getTitle()+
                "\", content=\""+answer.getContent()+
                "\",sender =\""+answer.getSender()+
                "\",sendtime=\""+answer.getSendtime()+
                "\" WHERE aid="+answer.getAid();
        System.out.println(sql);
        return executePs(sql);
    }
}
