package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DeptDAO extends BaseDao {
    //查询所有课程信息
    public ArrayList<DeptBean> selectAllDept(){
        ArrayList<DeptBean> deptList=new ArrayList<DeptBean>();
        String sql="SELECT * FROM dept";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                DeptBean dept=new DeptBean();
                dept.setName(rs.getString("name"));
                dept.setInfo(rs.getString("info"));
                deptList.add(dept);
            }
            rs.close();
            ps.close();
            conn.close();
            return deptList;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //获取学院信息
    public DeptBean selectInfo_Dept(String name){
        String sql="SELECT info FROM dept where name=\""+name+"\"";
        try {
            Connection conn=ds.getConnection();
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            DeptBean dept=new DeptBean();
            while(rs.next()){
                dept.setName(name);
                dept.setInfo(rs.getString("info"));
            }
            rs.close();
            ps.close();
            conn.close();
            return dept;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("error:"+e.toString());
            return null;
        }
    }

    //增加学院信息
    public boolean addDept(DeptBean dept){
        String sql="insert dept(name,info) values (\""+dept.getName()+ "\",\""+dept.getInfo()+"\")";
        System.out.println(sql);
        return executePs(sql);
    }

    //修改学院信息
    public boolean updateDeptInfo(DeptBean dept){
        String sql="UPDATE dept set info=\""+dept.getInfo()+
                "\"WHERE name=\""+dept.getName()+"\"";
        return executePs(sql);
    }

    //判断是否存在同名学院
    public boolean ifDeptExists(String name){
        Boolean deptExists=false;
        String sql="SELECT * FROM dept WHERE name=\""+name+"\"";
        try {
            return ifExists(deptExists, sql, ds.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
