package com.qasystem.model;

public class AnswerBean {
    private String aid;
    private String qid;
    private String course;
    private String title;
    private String content;
    private String sendtime;
    private String sender;

    public AnswerBean(){

    }

    public AnswerBean(String qid,String course,String title,
                      String content,String sender,String sendtime){
        this.qid=qid;
        this.course=course;
        this.title=title;
        this.content=content;
        this.sendtime=sendtime;
        this.sender=sender;
    }


    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSendtime() {
        return sendtime;
    }

    public void setSendtime(String sendtime) {
        this.sendtime = sendtime;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }
}
