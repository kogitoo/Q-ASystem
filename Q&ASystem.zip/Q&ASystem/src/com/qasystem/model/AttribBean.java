package com.qasystem.model;

public class AttribBean {
    //    1:是否以学生身份注册
    private boolean notStudent;
    //    2:是否注册成功
    private boolean registerSuccess;
    //    3:学生账户是否验证成功
    private boolean studentCheck;
    //    4:教师账户是否验证成功
    private boolean teacherCheck;
    //    5:管理员账户是否验证成功
    private boolean adminCheck;
    //    6:管理员浏览教师界面的状态锁（学生浏览教师界面）
    private boolean adminSelectTeacherLock;
    //    7:管理员添加教师信息失败
    private boolean adminAddTeacherFail;
    //    8:管理员删除教师信息失败
    private boolean adminDeleteTeacherFail;
    //    9:管理员修改教师信息失败
    private boolean adminUpdateTeacherFail;
    //    10:学生打开选择学院模态框
    private boolean stuChooseDept;
    //    11.根据学院浏览课程列表的状态锁
    private boolean stuSelectCourse_DeptCheck;
    //    12.根据课程名打开留言面板的状态锁
    private boolean stuSelectQuestion_CourseCheck;
    //    13.根据问题号打开留言及回复面板的状态锁
    private boolean SelectAnswer_QidCheck;
    //    14.根据教师浏览课程列表的状态锁
    private boolean stuSelectCourse_TeacherCheck;
    //    15.学生打开提问模态框
    private boolean stuAskQuestion;
    //    16.教师浏览课程列表的状态锁
    private boolean teacherSelectCourseCheck;
    //    17.管路员浏览课程列表的状态锁
    private boolean adminSelectCourseCheck;
    //    18.管理员打开添加课程模态框
    private boolean adminAddCourseCheck;
    //    19.管理员添加课程失败
    private boolean adminAddCourseFail;
    //    20.管理员删除课程失败
    private boolean adminDeleteCourseFail;
    //    21.管理员打开修改课程模态框
    private boolean adminUpdateCourseCheck;
    //    22.管理员浏览学院列表的状态锁
    private boolean adminSelectDeptCheck;
    //    23.管理员打开修改学院模态框
    private boolean adminUpdateDeptCheck;
    //    24.管理员增加新学院失败
    private boolean adminAddDeptFail;
    //    25.管理员浏览授课列表的状态锁
    private boolean adminSelectTeachesCheck;
//    26.管理员添加新授课记录失败
    private boolean adminAddTeachesFail;
//    27.学生注册失败
    private boolean stuRegisterFail;
//    28.用户重新注册
    private boolean ifUserResetPswd;
//    29.学生显示自己的留言一览
    private boolean stuSelectMyQuestion;
//30.学生打开修改留言的模态框
    private  boolean stuUpdateMyQuestion;
//    31.教师显示自己的回复一览
    private boolean teacherSelectMyQuestion;
//    32.教师打开修改留言的模态框
    private boolean teacherUpdateMyAnswer;
//    33.教师显示尚未回复的全部留言
    private boolean teacherSelectNewQuestion;
//    34.学生显示检索结果集
    private boolean stuShowSearchResult;


    public boolean isNotStudent() {
        return notStudent;
    }

    public void setNotStudent(boolean notStudent) {
        this.notStudent = notStudent;
    }

    public boolean isRegisterSuccess() {
        return registerSuccess;
    }

    public void setRegisterSuccess(boolean registerSuccess) {
        this.registerSuccess = registerSuccess;
    }

    public boolean isStudentCheck() {
        return studentCheck;
    }

    public void setStudentCheck(boolean studentCheck) {
        this.studentCheck = studentCheck;
    }

    public boolean isTeacherCheck() {
        return teacherCheck;
    }

    public void setTeacherCheck(boolean teacherCheck) {
        this.teacherCheck = teacherCheck;
    }

    public boolean isAdminCheck() {
        return adminCheck;
    }

    public void setAdminCheck(boolean adminCheck) {
        this.adminCheck = adminCheck;
    }

    public boolean isAdminSelectTeacherLock() {
        return adminSelectTeacherLock;
    }

    public void setAdminSelectTeacherLock(boolean adminSelectTeacherLock) {
        this.adminSelectTeacherLock = adminSelectTeacherLock;
    }

    public boolean isAdminAddTeacherFail() {
        return adminAddTeacherFail;
    }

    public void setAdminAddTeacherFail(boolean adminAddTeacherFail) {
        this.adminAddTeacherFail = adminAddTeacherFail;
    }

    public boolean isAdminDeleteTeacherFail() {
        return adminDeleteTeacherFail;
    }

    public void setAdminDeleteTeacherFail(boolean adminDeleteTeacherFail) {
        this.adminDeleteTeacherFail = adminDeleteTeacherFail;
    }

    public boolean isAdminUpdateTeacherFail() {
        return adminUpdateTeacherFail;
    }

    public void setAdminUpdateTeacherFail(boolean adminUpdateTeacherFail) {
        this.adminUpdateTeacherFail = adminUpdateTeacherFail;
    }

    public boolean isStuChooseDept() {
        return stuChooseDept;
    }

    public void setStuChooseDept(boolean stuChooseDept) {
        this.stuChooseDept = stuChooseDept;
    }

    public boolean isStuSelectCourse_DeptCheck() {
        return stuSelectCourse_DeptCheck;
    }

    public void setStuSelectCourse_DeptCheck(boolean stuSelectCourse_DeptCheck) {
        this.stuSelectCourse_DeptCheck = stuSelectCourse_DeptCheck;
    }

    public boolean isStuSelectQuestion_CourseCheck() {
        return stuSelectQuestion_CourseCheck;
    }

    public void setStuSelectQuestion_CourseCheck(boolean stuSelectQuestion_CourseCheck) {
        this.stuSelectQuestion_CourseCheck = stuSelectQuestion_CourseCheck;
    }

    public boolean isSelectAnswer_QidCheck() {
        return SelectAnswer_QidCheck;
    }

    public void setSelectAnswer_QidCheck(boolean selectAnswer_QidCheck) {
        SelectAnswer_QidCheck = selectAnswer_QidCheck;
    }

    public boolean isStuSelectCourse_TeacherCheck() {
        return stuSelectCourse_TeacherCheck;
    }

    public void setStuSelectCourse_TeacherCheck(boolean stuSelectCourse_TeacherCheck) {
        this.stuSelectCourse_TeacherCheck = stuSelectCourse_TeacherCheck;
    }

    public boolean isStuAskQuestion() {
        return stuAskQuestion;
    }

    public void setStuAskQuestion(boolean stuAskQuestion) {
        this.stuAskQuestion = stuAskQuestion;
    }

    public boolean isTeacherSelectCourseCheck() {
        return teacherSelectCourseCheck;
    }

    public void setTeacherSelectCourseCheck(boolean teacherSelectCourseCheck) {
        this.teacherSelectCourseCheck = teacherSelectCourseCheck;
    }

    public boolean isAdminSelectCourseCheck() {
        return adminSelectCourseCheck;
    }

    public void setAdminSelectCourseCheck(boolean adminSelectCourseCheck) {
        this.adminSelectCourseCheck = adminSelectCourseCheck;
    }

    public boolean isAdminAddCourseCheck() {
        return adminAddCourseCheck;
    }

    public void setAdminAddCourseCheck(boolean adminAddCourseCheck) {
        this.adminAddCourseCheck = adminAddCourseCheck;
    }

    public boolean isAdminAddCourseFail() {
        return adminAddCourseFail;
    }

    public void setAdminAddCourseFail(boolean adminAddCourseFail) {
        this.adminAddCourseFail = adminAddCourseFail;
    }

    public boolean isAdminDeleteCourseFail() {
        return adminDeleteCourseFail;
    }

    public void setAdminDeleteCourseFail(boolean adminDeleteCourseFail) {
        this.adminDeleteCourseFail = adminDeleteCourseFail;
    }

    public boolean isAdminUpdateCourseCheck() {
        return adminUpdateCourseCheck;
    }

    public void setAdminUpdateCourseCheck(boolean adminUpdateCourseCheck) {
        this.adminUpdateCourseCheck = adminUpdateCourseCheck;
    }

    public boolean isAdminSelectDeptCheck() {
        return adminSelectDeptCheck;
    }

    public void setAdminSelectDeptCheck(boolean adminSelectDeptCheck) {
        this.adminSelectDeptCheck = adminSelectDeptCheck;
    }

    public boolean isAdminUpdateDeptCheck() {
        return adminUpdateDeptCheck;
    }

    public void setAdminUpdateDeptCheck(boolean adminUpdateDeptCheck) {
        this.adminUpdateDeptCheck = adminUpdateDeptCheck;
    }

    public boolean isAdminAddDeptFail() {
        return adminAddDeptFail;
    }

    public void setAdminAddDeptFail(boolean adminAddDeptFail) {
        this.adminAddDeptFail = adminAddDeptFail;
    }

    public boolean isAdminSelectTeachesCheck() {
        return adminSelectTeachesCheck;
    }

    public void setAdminSelectTeachesCheck(boolean adminSelectTeachesCheck) {
        this.adminSelectTeachesCheck = adminSelectTeachesCheck;
    }

    public boolean isAdminAddTeachesFail() {
        return adminAddTeachesFail;
    }

    public void setAdminAddTeachesFail(boolean adminAddTeachesFail) {
        this.adminAddTeachesFail = adminAddTeachesFail;
    }

    public boolean isStuRegisterFail() {
        return stuRegisterFail;
    }

    public void setStuRegisterFail(boolean stuRegisterFail) {
        this.stuRegisterFail = stuRegisterFail;
    }

    public boolean isIfUserResetPswd() {
        return ifUserResetPswd;
    }

    public void setIfUserResetPswd(boolean ifUserResetPswd) {
        this.ifUserResetPswd = ifUserResetPswd;
    }

    public boolean isStuSelectMyQuestion() {
        return stuSelectMyQuestion;
    }

    public void setStuSelectMyQuestion(boolean stuSelectMyQuestion) {
        this.stuSelectMyQuestion = stuSelectMyQuestion;
    }

    public boolean isStuUpdateMyQuestion() {
        return stuUpdateMyQuestion;
    }

    public void setStuUpdateMyQuestion(boolean stuUpdateMyQuestion) {
        this.stuUpdateMyQuestion = stuUpdateMyQuestion;
    }

    public boolean isTeacherSelectMyQuestion() {
        return teacherSelectMyQuestion;
    }

    public void setTeacherSelectMyQuestion(boolean teacherSelectMyQuestion) {
        this.teacherSelectMyQuestion = teacherSelectMyQuestion;
    }

    public boolean isTeacherUpdateMyAnswer() {
        return teacherUpdateMyAnswer;
    }

    public void setTeacherUpdateMyAnswer(boolean teacherUpdateMyAnswer) {
        this.teacherUpdateMyAnswer = teacherUpdateMyAnswer;
    }

    public boolean isTeacherSelectNewQuestion() {
        return teacherSelectNewQuestion;
    }

    public void setTeacherSelectNewQuestion(boolean teacherSelectNewQuestion) {
        this.teacherSelectNewQuestion = teacherSelectNewQuestion;
    }

    public boolean isStuShowSearchResult() {
        return stuShowSearchResult;
    }

    public void setStuShowSearchResult(boolean stuShowSearchResult) {
        this.stuShowSearchResult = stuShowSearchResult;
    }
}
