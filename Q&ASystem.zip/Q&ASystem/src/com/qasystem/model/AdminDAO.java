package com.qasystem.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO  extends BaseDao{
    public boolean checkAdmin(AdminBean admin){
        String sql="SELECT password FROM admin WHERE name=?";
        String name=admin.getName();
        String pswd=admin.getPassword();
        try {
            return checkIdentity(sql,ds.getConnection(),name,pswd);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //重置密码
    public boolean resetPassword(String name,String password){
        String sql="UPDATE admin set password=\""+password+
                "\"WHERE name=\""+name+"\"";
        return executePs(sql);
    }
}
