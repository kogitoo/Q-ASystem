package com.qasystem.filter;

import com.qasystem.model.AttribBean;
import com.sun.deploy.net.HttpRequest;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@WebFilter(
    filterName = "adminPageFilter",
    urlPatterns ="/adminPage.jsp",
    initParams = {@WebInitParam(name = "encoding", value = "UTF-8")
    }
)

public class adminPageFilter implements Filter {
    private FilterConfig config;
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        //设置请求request的编码字符集
        resp.setContentType("text/html;charset=UTF-8");
        req.setCharacterEncoding("utf-8");
        HttpServletRequest request=(HttpServletRequest)req;
        if(request.getAttribute("attrib5")==null ){
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
        }
        else{
            chain.doFilter(req, resp);
        }

    }

    public void init(FilterConfig config) throws ServletException {
        this.config=config;
    }

}
