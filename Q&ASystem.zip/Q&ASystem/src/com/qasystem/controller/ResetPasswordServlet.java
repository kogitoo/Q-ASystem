package com.qasystem.controller;

import com.qasystem.model.AdminDAO;
import com.qasystem.model.AttribBean;
import com.qasystem.model.StudentDAO;
import com.qasystem.model.TeacherDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.stream.events.Attribute;
import java.io.IOException;

@WebServlet(name = "ResetPasswordServlet",urlPatterns =  {"/ResetPasswordServlet"})
public class ResetPasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String name=request.getParameter("name");
        String password=request.getParameter("password");
        String page=request.getParameter("page");
        if(page != null && page.equals("admin")){
            AdminDAO dao=new AdminDAO();
            dao.resetPassword(name,password);
        }
        else if(page != null && page.equals("teacher")){
            TeacherDAO dao=new TeacherDAO();
            dao.resetPassword(name,password);
        }
        else if(page != null && page.equals("student")){
            StudentDAO dao=new StudentDAO();
            dao.resetPassword(name,password);
        }
        //退回主页重新登录
        AttribBean attrib28=new AttribBean();
        attrib28.setIfUserResetPswd(true);
        request.setAttribute("attrib28",attrib28);
        RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
        rd.forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
