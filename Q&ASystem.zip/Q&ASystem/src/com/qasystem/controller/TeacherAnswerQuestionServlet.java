package com.qasystem.controller;

import com.qasystem.model.AnswerBean;
import com.qasystem.model.AnswerDAO;
import com.qasystem.model.QuestionBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "TeacherAnswerQuestionServlet",urlPatterns = {"/TeacherAnswerQuestionServlet"})
public class TeacherAnswerQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        //view-->controller
        String qid=request.getParameter("qid");
        String course=request.getParameter("course");
        String title=request.getParameter("title");
        String content=request.getParameter("content");
        HttpSession session=request.getSession();
        String sender=(String)session.getAttribute("loginTeacher");
        SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//日期格式
        Date currentTime=new Date();//得到当前系统时间
        String sendtime=formatter.format(currentTime);//将日期时间格式化为str_date1
        //封装
        AnswerBean answer=new AnswerBean(qid,course,title,content,sender,sendtime);
        //controller-->model
        AnswerDAO adao=new AnswerDAO();
        boolean success=adao.addAnswer(answer);
        request.getRequestDispatcher("ShowAnswerServlet?qid="+answer.getQid()+"&page=teacher").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
