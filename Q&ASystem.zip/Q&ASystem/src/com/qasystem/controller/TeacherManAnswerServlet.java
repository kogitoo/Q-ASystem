package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

@WebServlet(name = "TeacherManAnswerServlet",urlPatterns = {"/TeacherManAnswerServlet"})
public class TeacherManAnswerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String func=(String)request.getParameter("func");
        String aid=(String)request.getParameter("aid");
        if(func!=null && func.equals("delete")){
            AnswerDAO adao=new AnswerDAO();
            boolean success=adao.deleteAnswer(aid);

            //刷新页面
            HttpSession session=request.getSession();
            String tname=(String)( session.getAttribute("loginTeacher"));
            request.getRequestDispatcher("ShowAnswerServlet?page=teachermya&tname="+tname).forward(request, response);

        }
        else if(func!=null && func.equals("select")){
            AnswerDAO adao=new AnswerDAO();
            AnswerBean answer=adao.selectOneAnswer(aid);

            //刷新页面
            HttpSession session=request.getSession();
            String tname=(String)( session.getAttribute("loginTeacher"));
            request.setAttribute("answer",answer);
            AttribBean attrib32=new AttribBean();
            attrib32.setTeacherUpdateMyAnswer(true);
            request.setAttribute("attrib32",attrib32);
            ArrayList<AnswerBean> answerList=(ArrayList<AnswerBean>)adao.selectAllAnswer_Sender(tname).clone();

            AttribBean attrib31=new AttribBean();
            attrib31.setTeacherSelectMyQuestion(true);
            request.setAttribute("answerList",answerList);
            request.setAttribute("attrib31",attrib31);

            //跳转
            request.getRequestDispatcher("teacherPage.jsp").forward(request, response);
        }
        else if(func !=null && func.equals("update")){
            String title=request.getParameter("title");
            String content=request.getParameter("content");
            HttpSession session=request.getSession();
            String sender=(String)session.getAttribute("loginTeacher");
            SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//日期格式
            Date currentTime=new Date();//得到当前系统时间
            String sendtime=formatter.format(currentTime);//将日期时间格式化为str_date1

            //封装
            AnswerBean answer=new AnswerBean();
            answer.setAid(aid);
            answer.setTitle(title);
            answer.setContent(content);
            answer.setSender(sender);
            answer.setSendtime(sendtime);

            //controller<-->model
            AnswerDAO dao=new AnswerDAO();
            boolean success=dao.updateAnswer(answer);

            //刷新页面
            request.getRequestDispatcher("ShowAnswerServlet?page=teachermya&tname="+sender).forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
