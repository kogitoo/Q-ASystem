package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "ShowQuestionServlet" ,urlPatterns = {"/ShowQuestionServlet"})
public class ShowQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String page=request.getParameter("page");
        if(page != null && page.equals("student")){
            String courseName = request.getParameter("courseName");
            CourseDAO cdao=new CourseDAO();
            ArrayList<CourseBean> courseList=(ArrayList<CourseBean>)(cdao.selectCourse_cName(courseName).clone());
            QuestionDAO dao=new QuestionDAO();
            ArrayList<QuestionBean> questionList=(ArrayList<QuestionBean>)(dao.selectAllQuestion_Course(courseName).clone());
            AttribBean attrib12=new AttribBean();
            attrib12.setStuSelectQuestion_CourseCheck(true);
            request.setAttribute("questionList",questionList);
            request.setAttribute("attrib12",attrib12);
            request.setAttribute("courseName",courseName);
            request.setAttribute("courseList",courseList);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        else if(page !=null && page.equals("teacher")){
            String courseName = request.getParameter("courseName");
            CourseDAO cdao=new CourseDAO();
            ArrayList<CourseBean> courseList=(ArrayList<CourseBean>)(cdao.selectCourse_cName(courseName).clone());
            QuestionDAO dao=new QuestionDAO();
            ArrayList<QuestionBean> questionList=(ArrayList<QuestionBean>)(dao.selectAllQuestion_Course(courseName).clone());
            AttribBean attrib12=new AttribBean();
            attrib12.setStuSelectQuestion_CourseCheck(true);
            request.setAttribute("questionList",questionList);
            request.setAttribute("attrib12",attrib12);
            request.setAttribute("courseName",courseName);
            request.setAttribute("courseList",courseList);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/teacherPage.jsp");
            rd.forward(request, response);
        }
        //学生查看自己的所有提问
        else if(page!=null && page.equals("studentmyq")){
            String courseName = request.getParameter("courseName");
            QuestionDAO dao=new QuestionDAO();
            HttpSession session=request.getSession();
            session.setAttribute("stuAEQuestionImage",false);
            String sender=(String)( session.getAttribute("loginStudent"));
            ArrayList<QuestionBean> questionList2=(ArrayList<QuestionBean>)(dao.selectAllQuestion_Sender(sender).clone());
            AttribBean attrib29=new AttribBean();
            attrib29.setStuSelectMyQuestion(true);
            request.setAttribute("attrib29",attrib29);
            request.setAttribute("questionList2",questionList2);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        //教师查看还没有回复的问题
        else if(page!=null && page.equals("teachernq")){
            HttpSession session=request.getSession();
            String tname=(String)( session.getAttribute("loginTeacher"));
            //获取该教师所有授课信息
            TeacherBean teacher=new TeacherBean();
            teacher.setName(tname);
            ArrayList<TeacherBean> thisTeacher=new ArrayList<TeacherBean>();
            thisTeacher.add(teacher);

            TeacherDAO tdao=new TeacherDAO();
            thisTeacher=tdao.selectCourseForTeacher(thisTeacher);
            teacher=thisTeacher.get(0);

            //获得全部课程中全部问题的问题列表
            ArrayList<QuestionBean> allQuestionList=new ArrayList<QuestionBean>();

            //遍历课程列表获得所有课程的所有问题
            QuestionDAO qdao=new QuestionDAO();
            for(int i=0;i<teacher.getCourseList().size();i++){
                ArrayList<QuestionBean> questionList=new ArrayList<QuestionBean>();
                questionList=(ArrayList<QuestionBean>)(qdao.selectAllNewQuestion_Course(teacher.getCourseList().get(i)).clone());
                allQuestionList.addAll(questionList);
            }

            AttribBean attrib33=new AttribBean();
            attrib33.setTeacherSelectNewQuestion(true);
            request.setAttribute("attrib33",attrib33);

            request.setAttribute("allQuestionList",allQuestionList);
            session.setAttribute("newQuestionImage",false);

            request.getRequestDispatcher("teacherPage.jsp").forward(request,response);
        }
        //学生检索
        else if(page!=null && page.equals("studentSearch")){
            String keyword=request.getParameter("keyword");
            String scope=request.getParameter("option");
            scope=scope.replace("标题名","title");
            scope=scope.replace("留言内容","content");
            scope=scope.replace("留言提出人","sender");
            scope=scope.replace("课程名","course");

            QuestionDAO dao=new QuestionDAO();
            ArrayList<QuestionBean> questionList2=(ArrayList<QuestionBean>)(dao.search(keyword,scope));
            AttribBean attrib29=new AttribBean();
            attrib29.setStuSelectMyQuestion(true);
            request.setAttribute("attrib29",attrib29);
            request.setAttribute("questionList2",questionList2);

            AttribBean attrib34=new AttribBean();
            attrib34.setStuShowSearchResult(true);
            request.setAttribute("attrib34",attrib34);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);

        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
