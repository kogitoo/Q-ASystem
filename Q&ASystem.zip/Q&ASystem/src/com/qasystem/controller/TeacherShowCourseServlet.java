package com.qasystem.controller;

import com.qasystem.model.AttribBean;
import com.qasystem.model.CourseBean;
import com.qasystem.model.CourseDAO;
import com.qasystem.model.TeachesDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "TeacherShowCourseServlet",urlPatterns =  {"/TeacherShowCourseServlet"})
public class TeacherShowCourseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String teacherName = request.getParameter("teacherName");
        //先通过教师名获取其所交课程名
        TeachesDAO tsdao=new TeachesDAO();
        ArrayList<CourseBean> cnameList = (ArrayList<CourseBean>) (tsdao.selectAllCname_Tname(teacherName)).clone();
        //再通过课程名表获得课程信息一览表
        CourseDAO cdao=new CourseDAO();
        ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (cdao.selectCourse_cnameList(cnameList)).clone();
        AttribBean attrib16=new AttribBean();
        attrib16.setTeacherSelectCourseCheck(true);
        request.setAttribute("attrib16",attrib16);
        request.setAttribute("courseList",courseList);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/teacherPage.jsp");
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
