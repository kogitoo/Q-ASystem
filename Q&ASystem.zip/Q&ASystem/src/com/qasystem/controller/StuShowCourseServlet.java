package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "StuShowCourseServlet",urlPatterns = {"/StuShowCourseServlet"})
public class StuShowCourseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String rid = request.getParameter("id");

        //返回学院名字
        if (rid!= null && rid.trim().equals("1")) {
            DeptDAO dao = new DeptDAO();
            ArrayList<DeptBean> deptList = (ArrayList<DeptBean>) (dao.selectAllDept()).clone();
            AttribBean attrib10 = new AttribBean();
            attrib10.setStuChooseDept(true);
            request.setAttribute("deptList", deptList);
            request.setAttribute("attrib10", attrib10);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        //根据学院返回课程列表
        else if(rid!= null && rid.trim().equals("2")){
            String deptName=request.getParameter("option");
            CourseDAO dao = new CourseDAO();
            ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse_Dept(deptName)).clone();
            AttribBean attrib11=new AttribBean();
            attrib11.setStuSelectCourse_DeptCheck(true);
            request.setAttribute("attrib11",attrib11);
            request.setAttribute("courseList",courseList);
            request.setAttribute("deptName",deptName);

            //再返回该学院的相关信息
            DeptDAO ddao=new DeptDAO();
            DeptBean dept=new DeptBean();
            dept=ddao.selectInfo_Dept(deptName);
            request.setAttribute("dept",dept);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        //返回教师姓名
        if (rid!= null && rid.trim().equals("3")) {
            TeacherDAO dao=new TeacherDAO();
            ArrayList<TeacherBean> teacherList = (ArrayList<TeacherBean>) (dao.selectAllTeacher().clone());
            AttribBean attrib6 = new AttribBean();
            attrib6.setAdminSelectTeacherLock(true);
            request.setAttribute("teacherList", teacherList);
            request.setAttribute("attrib6", attrib6);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        //根据教师返回课程列表
        else if(rid!= null && rid.trim().equals("4")){
            String teacherName=request.getParameter("option2");
            //先通过教师名获取其所交课程名
            TeachesDAO tsdao=new TeachesDAO();
            ArrayList<CourseBean> cnameList = (ArrayList<CourseBean>) (tsdao.selectAllCname_Tname(teacherName)).clone();
            CourseDAO cdao=new CourseDAO();
            ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (cdao.selectCourse_cnameList(cnameList)).clone();
            AttribBean attrib14=new AttribBean();
            attrib14.setStuSelectCourse_TeacherCheck(true);
            request.setAttribute("attrib14",attrib14);
            request.setAttribute("courseList",courseList);
            request.setAttribute("teacherName",teacherName);

            //再返回该教师的相关信息
            TeacherDAO tdao=new TeacherDAO();
            TeacherBean teacher=new TeacherBean();
            teacher=tdao.selectOneTeacher(teacherName);
            request.setAttribute("teacher",teacher);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
