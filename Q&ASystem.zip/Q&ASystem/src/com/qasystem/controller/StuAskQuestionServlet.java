package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

@WebServlet(name = "StuAskQuestionServlet",urlPatterns = {"/StuAskQuestionServlet"})
public class StuAskQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String rid=request.getParameter("rid");
        //返回课程列表给提问模态框
        if(rid != null && rid.equals("1")){
            CourseDAO cdao=new CourseDAO();
            ArrayList<CourseBean> courseList=(ArrayList<CourseBean>)(cdao.selectAllCourse().clone());
            AttribBean attrib15=new AttribBean();
            attrib15.setStuAskQuestion(true);
            request.setAttribute("attrib15",attrib15);
            request.setAttribute("courseList",courseList);
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request,response);
        }
//        增加提问留言记录
        else if(rid != null && rid.equals("2")){
            //view-->controller
            String title=request.getParameter("title");
            String content=request.getParameter("content");
            String course=request.getParameter("option");
            HttpSession session=request.getSession();
            String sender=(String)session.getAttribute("loginStudent");
            SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//日期格式
            Date currentTime=new Date();//得到当前系统时间
            String sendtime=formatter.format(currentTime);//将日期时间格式化为str_date1
            //封装
            QuestionBean question=new QuestionBean();
            question.setTitle(title);
            question.setCourse(course);
            question.setContent(content);
            question.setSender(sender);
            question.setSendtime(sendtime);
            //controller-->model
            QuestionDAO qdao=new QuestionDAO();
            boolean success=qdao.addQuestion(question);
            request.getRequestDispatcher("ShowQuestionServlet?courseName="+course+"&page=student").forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
