package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

@WebServlet(name = "StuManQuestionServlet",urlPatterns = {"/StuManQuestionServlet"})
public class StuManQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String func=(String)request.getParameter("func");
        String qid=(String)request.getParameter("qid");
        if(func!=null && func.equals("select")){
//            返回该问题留言的信息
            QuestionDAO dao1=new QuestionDAO();
            QuestionBean question=new QuestionBean();
            question=dao1.selectAllQuestion_Qid(qid).get(0);
            request.setAttribute("question",question);

            CourseDAO cdao=new CourseDAO();
            ArrayList<CourseBean> courseList=(ArrayList<CourseBean>)(cdao.selectAllCourse().clone());
            request.setAttribute("courseList",courseList);

            AttribBean attrib30=new AttribBean();
            attrib30.setStuUpdateMyQuestion(true);
            request.setAttribute("attrib30",attrib30);

            //刷新页面
            HttpSession session=request.getSession();
            String sender=(String)( session.getAttribute("loginStudent"));
            ArrayList<QuestionBean> questionList2=(ArrayList<QuestionBean>)(dao1.selectAllQuestion_Sender(sender).clone());
            AttribBean attrib29=new AttribBean();
            attrib29.setStuSelectMyQuestion(true);
            request.setAttribute("attrib29",attrib29);
            request.setAttribute("questionList2",questionList2);


            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);

        }
        //删除该问题
        else if(func!=null && func.equals("delete")){
            QuestionDAO dao2=new QuestionDAO();
            boolean success=dao2.deleteQuestion(qid);

            //刷新页面
            HttpSession session=request.getSession();
            String sender=(String)( session.getAttribute("loginStudent"));
            ArrayList<QuestionBean> questionList2=(ArrayList<QuestionBean>)(dao2.selectAllQuestion_Sender(sender).clone());
            AttribBean attrib29=new AttribBean();
            attrib29.setStuSelectMyQuestion(true);
            request.setAttribute("attrib29",attrib29);
            request.setAttribute("questionList2",questionList2);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        else if(func!=null && func.equals("teacherDelete")){
            System.out.println("跳转成功");
            QuestionDAO dao2=new QuestionDAO();
            boolean success=dao2.deleteQuestion(qid);

            //刷新页面
            HttpSession session=request.getSession();
            String tname=(String)( session.getAttribute("loginTeacher"));
            request.getRequestDispatcher("TeacherShowCourseServlet?teacherName="+tname).forward(request, response);

        }
        else if(func!=null && func.equals("update")){
            //view-->controller
            String title=(String) request.getParameter("title");
            String course=(String)request.getParameter("option2");
            String content=(String)request.getParameter("content");
            HttpSession session=request.getSession();
            String sender=(String)session.getAttribute("loginStudent");
            SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//日期格式
            Date currentTime=new Date();//得到当前系统时间
            String sendtime=formatter.format(currentTime);//将日期时间格式化为str_date1
            //封装
            QuestionBean question=new QuestionBean();
            question.setTitle(title);
            question.setCourse(course);
            question.setContent(content);
            question.setSender(sender);
            question.setSendtime(sendtime);
            question.setQid(qid);

            //controller-->model
            QuestionDAO qdao=new QuestionDAO();

            boolean success=qdao.updateQuestion(question);

            //刷新页面
            ArrayList<QuestionBean> questionList2=(ArrayList<QuestionBean>)(qdao.selectAllQuestion_Sender(sender).clone());
            AttribBean attrib29=new AttribBean();
            attrib29.setStuSelectMyQuestion(true);
            request.setAttribute("attrib29",attrib29);
            request.setAttribute("questionList2",questionList2);


            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
