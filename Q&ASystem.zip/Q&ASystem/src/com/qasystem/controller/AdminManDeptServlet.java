package com.qasystem.controller;

import com.qasystem.model.AttribBean;
import com.qasystem.model.DeptBean;
import com.qasystem.model.DeptDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AdminManDeptServlet",urlPatterns = {"/AdminManDeptServlet"})
public class AdminManDeptServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String rid = request.getParameter("id");
        //返回学院列表
        if(rid!= null && rid.trim().equals("1")){
            DeptBean dept=new DeptBean();
            DeptDAO dao=new DeptDAO();
            ArrayList<DeptBean> deptList=(ArrayList<DeptBean>)(dao.selectAllDept().clone());
            AttribBean attrib22=new AttribBean();
            attrib22.setAdminSelectDeptCheck(true);
            request.setAttribute("deptList",deptList);
            request.setAttribute("attrib22",attrib22);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        //返回学院信息
        else if(rid!= null && rid.trim().equals("2")){
            String dname=request.getParameter("name");
            DeptDAO dao=new DeptDAO();
            DeptBean dept=new DeptBean();
            dept=dao.selectInfo_Dept(dname);
            request.setAttribute("dept",dept);
            AttribBean attrib23=new AttribBean();
            attrib23.setAdminUpdateDeptCheck(true);
            request.setAttribute("attrib23",attrib23);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        else if(rid!= null && rid.trim().equals("3")){
            String dname=request.getParameter("name");
            String dinfo=request.getParameter("info");
            DeptBean dept=new DeptBean();
            dept.setName(dname);
            dept.setInfo(dinfo);
            DeptDAO dao=new DeptDAO();
            boolean success=dao.updateDeptInfo(dept);

            //刷新学院一览
            ArrayList<DeptBean> deptList=(ArrayList<DeptBean>)(dao.selectAllDept().clone());
            AttribBean attrib22=new AttribBean();
            attrib22.setAdminSelectDeptCheck(true);
            request.setAttribute("deptList",deptList);
            request.setAttribute("attrib22",attrib22);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        else if(rid!= null && rid.trim().equals("4")){
            String name=request.getParameter("dname");
            String info=request.getParameter("dinfo");
            DeptDAO dao=new DeptDAO();
            DeptBean dept=new DeptBean();
            dept.setName(name);
            dept.setInfo(info);
            //判断是否存在同名学院
            if(!dao.ifDeptExists(name)){
                //不存在，则添加该学院信息
                boolean success=dao.addDept(dept);
                //刷新学院一览
                ArrayList<DeptBean> deptList=(ArrayList<DeptBean>)(dao.selectAllDept().clone());
                AttribBean attrib22=new AttribBean();
                attrib22.setAdminSelectDeptCheck(true);
                request.setAttribute("deptList",deptList);
                request.setAttribute("attrib22",attrib22);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }else{
                AttribBean attrib23=new AttribBean();
                attrib23.setAdminAddDeptFail(true);
                request.setAttribute("attrib23",attrib23);
                //刷新学院一览
                ArrayList<DeptBean> deptList=(ArrayList<DeptBean>)(dao.selectAllDept().clone());
                AttribBean attrib22=new AttribBean();
                attrib22.setAdminSelectDeptCheck(true);
                request.setAttribute("deptList",deptList);
                request.setAttribute("attrib22",attrib22);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }

        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
