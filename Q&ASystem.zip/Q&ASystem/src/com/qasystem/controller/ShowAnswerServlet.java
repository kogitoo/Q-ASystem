package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "ShowAnswerServlet",urlPatterns = {"/ShowAnswerServlet"})
public class ShowAnswerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String page=request.getParameter("page");

        if(page!=null && page.equals("student")){
            String qid = request.getParameter("qid");
            //获取回复信息
            AnswerDAO adao=new AnswerDAO();
            ArrayList<AnswerBean> answerList=(ArrayList<AnswerBean>)(adao.selectAllAnswer_Question(qid).clone());
            //获取提问信息
            QuestionDAO qdao=new QuestionDAO();
            ArrayList<QuestionBean> questionList=(ArrayList<QuestionBean>)(qdao.selectAllQuestion_Qid(qid).clone());
            //设置返回的逻辑值
            AttribBean attrib13=new AttribBean();
            attrib13.setSelectAnswer_QidCheck(true);
            request.setAttribute("questionList",questionList);
            request.setAttribute("answerList",answerList);
            request.setAttribute("attrib13",attrib13);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentPage.jsp");
            rd.forward(request, response);
        }
        else if(page!=null && page.equals("teacher")){
            String qid = request.getParameter("qid");
            //获取回复信息
            AnswerDAO adao=new AnswerDAO();
            ArrayList<AnswerBean> answerList=(ArrayList<AnswerBean>)(adao.selectAllAnswer_Question(qid).clone());
            //获取提问信息
            QuestionDAO qdao=new QuestionDAO();
            ArrayList<QuestionBean> questionList=(ArrayList<QuestionBean>)(qdao.selectAllQuestion_Qid(qid).clone());
            //设置返回的逻辑值
            AttribBean attrib13=new AttribBean();
            attrib13.setSelectAnswer_QidCheck(true);
            request.setAttribute("questionList",questionList);
            request.setAttribute("answerList",answerList);
            request.setAttribute("attrib13",attrib13);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/teacherPage.jsp");
            rd.forward(request, response);
        }
        //教师查看自己的所有回答
        else if(page!=null && page.equals("teachermya")){
            String tname=request.getParameter("tname");

            //获取该教师名下的所有答复
            AnswerDAO adao=new AnswerDAO();
            ArrayList<AnswerBean> answerList=(ArrayList<AnswerBean>)adao.selectAllAnswer_Sender(tname).clone();

            AttribBean attrib31=new AttribBean();
            attrib31.setTeacherSelectMyQuestion(true);

            request.setAttribute("answerList",answerList);
            request.setAttribute("attrib31",attrib31);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/teacherPage.jsp");
            rd.forward(request, response);


        }
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
