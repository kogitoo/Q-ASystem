package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AdminManCourseServlet" ,urlPatterns = {"/AdminManCourseServlet"})
public class AdminManCourseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String rid = request.getParameter("id");

        //返回学院名字
        if (rid!= null && rid.trim().equals("1")) {
            DeptDAO dao = new DeptDAO();
            ArrayList<DeptBean> deptList = (ArrayList<DeptBean>) (dao.selectAllDept()).clone();
            AttribBean attrib18 = new AttribBean();
            attrib18.setAdminAddCourseCheck(true);
            request.setAttribute("deptList", deptList);
            request.setAttribute("attrib18", attrib18);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        //添加课程信息
        else if(rid!= null && rid.trim().equals("2")) {
            System.out.println("跳转成功");
            CourseDAO dao = new CourseDAO();
            CourseBean course = new CourseBean();
            //vc
            course.setName(request.getParameter("cname"));
            course.setDept(request.getParameter("cdept"));
            course.setInfo(request.getParameter("cinfo"));

            //cm
            //课程不存在，则可添加
            if(!dao.ifCourseExists(course.getName())){
                boolean success=dao.addCourse(course);

                //显示课程
                AttribBean attrib17=new AttribBean();
                ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse()).clone();
                attrib17.setAdminSelectCourseCheck(true);
                request.setAttribute("attrib17",attrib17);
                request.setAttribute("courseList",courseList);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }else{
                AttribBean attrib17=new AttribBean();
                AttribBean attrib19=new AttribBean();
                ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse()).clone();
                attrib17.setAdminSelectCourseCheck(true);
                request.setAttribute("attrib17",attrib17);
                attrib19.setAdminAddCourseFail(true);
                request.setAttribute("attrib19",attrib19);
                request.setAttribute("courseList",courseList);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
        }
        //删除课程信息
        else if(rid!= null && rid.trim().equals("3")){
            CourseDAO dao = new CourseDAO();
            CourseBean course = new CourseBean();
            //vc
            course.setName(request.getParameter("cname2"));

            //cm
            //课程存在，则可删除
            if(dao.ifCourseExists(course.getName())){
                dao.deleteCourse(course);
                //显示课程
                AttribBean attrib17=new AttribBean();
                ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse()).clone();
                attrib17.setAdminSelectCourseCheck(true);
                request.setAttribute("attrib17",attrib17);
                System.out.println(attrib17);
                request.setAttribute("courseList",courseList);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
            else{
                AttribBean attrib20=new AttribBean();
                attrib20.setAdminDeleteCourseFail(true);
                request.setAttribute("attrib20",attrib20);
                //显示课程
                AttribBean attrib17=new AttribBean();
                ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse()).clone();
                attrib17.setAdminSelectCourseCheck(true);
                request.setAttribute("attrib17",attrib17);
                request.setAttribute("courseList",courseList);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
        }
//        返回单个课程信息
        else if(rid!= null && rid.trim().equals("4")){
            String name=request.getParameter("name");
            System.out.println("跳转成功："+name);
            CourseBean course;
            CourseDAO dao=new CourseDAO();
            //返回课程信息
            course=dao.selectCourse_cName(name).get(0);
            request.setAttribute("course",course);

            //返回学院列表
            DeptDAO ddao = new DeptDAO();
            ArrayList<DeptBean> deptList = (ArrayList<DeptBean>) (ddao.selectAllDept()).clone();
            request.setAttribute("deptList", deptList);

            //打开修改模态框
            AttribBean attrib21=new AttribBean();
            attrib21.setAdminUpdateCourseCheck(true);
            request.setAttribute("attrib21",attrib21);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        else if(rid!= null && rid.trim().equals("5")){
            String name=request.getParameter("name");
            String dept=request.getParameter("dept");
            String info=request.getParameter("info");
            CourseBean course=new CourseBean();
            course.setName(name);
            course.setDept(dept);
            course.setInfo(info);
            CourseDAO dao=new CourseDAO();
            boolean success=dao.updateCourse(course);
            //显示课程
            AttribBean attrib17=new AttribBean();
            ArrayList<CourseBean> courseList = (ArrayList<CourseBean>) (dao.selectAllCourse()).clone();
            attrib17.setAdminSelectCourseCheck(true);
            request.setAttribute("attrib17",attrib17);
            request.setAttribute("courseList",courseList);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
