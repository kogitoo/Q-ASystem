package com.qasystem.controller;

import com.qasystem.model.AttribBean;
import com.qasystem.model.TeacherBean;
import com.qasystem.model.TeacherDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

@WebServlet(name = "AdminManTeacherServlet" ,urlPatterns = {"/AdminManTeacherServlet"})
public class AdminManTeacherServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String aname = request.getParameter("id");

        //显示全部教师信息
        if (aname != null && aname.trim().equals("1")) {
            AttribBean attrib6 = new AttribBean();
            attrib6.setAdminSelectTeacherLock(true);
            ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
            request.setAttribute("teacherList",teacherCourseList);
            request.setAttribute("attrib6", attrib6);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request, response);
        }
        //增加一条教师信息
        else if(aname != null && aname.trim().equals("2")){
            TeacherDAO dao=new TeacherDAO();
            TeacherBean teacher=new TeacherBean();
            teacher.setName(request.getParameter("name"));
            //如果不存在该老师的记录，则执行添加
            if(!dao.ifTeacherExists(teacher.getName())){
                teacher.setCourseStr(request.getParameter("courseList"));
                ArrayList cList=new ArrayList(Arrays.asList(teacher.getCourseStr().split("、")));
                for(int i = 0; i < cList.size(); i++){
                    System.out.println("授课："+cList.get(i));
                }
                teacher.setCourseList(cList);
                teacher.setTitle(request.getParameter("title"));
                teacher.setInfo(request.getParameter("info"));
                //加入教师表
                dao.addTeacher(teacher);
                //加入授课表
                for(int i = 0; i < cList.size(); i++){
                    dao.addCourseForTeacher(teacher,i);
                }
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
            else{
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                AttribBean attrib7 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                attrib7.setAdminAddTeacherFail(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                request.setAttribute("attrib7", attrib7);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
        }
        //删除一条教师信息
        else if(aname != null && aname.trim().equals("3")){
            TeacherDAO dao=new TeacherDAO();
            TeacherBean teacher=new TeacherBean();
            teacher.setName(request.getParameter("name"));
            //如果存在该老师的记录，则删除
            if(dao.ifTeacherExists(teacher.getName())){
                dao.deleteTeacher(teacher);
                dao.deleteCourseForTeacher(teacher);
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
            else{
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                AttribBean attrib8 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                attrib8.setAdminDeleteTeacherFail(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                request.setAttribute("attrib8", attrib8);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
        }
        //修改一条教师信息
        else if(aname != null && aname.trim().equals("4")){
            TeacherDAO dao=new TeacherDAO();
            TeacherBean teacher=new TeacherBean();
            teacher.setName(request.getParameter("name"));
            //如果存在该老师的记录，则修改
            if(dao.ifTeacherExists(teacher.getName())){
                teacher.setTitle(request.getParameter("title"));
                teacher.setInfo(request.getParameter("info"));
                dao.updateTeacher(teacher);
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
            else{
                //自动刷新教师信息一览表
                AttribBean attrib6 = new AttribBean();
                AttribBean attrib9 = new AttribBean();
                attrib6.setAdminSelectTeacherLock(true);
                attrib9.setAdminUpdateTeacherFail(true);
                ArrayList<TeacherBean> teacherCourseList=viewAllTeacher();
                request.setAttribute("teacherList",teacherCourseList);
                request.setAttribute("attrib6", attrib6);
                request.setAttribute("attrib9", attrib9);
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request, response);
            }
        }
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected  ArrayList<TeacherBean> viewAllTeacher(){
        TeacherDAO dao=new TeacherDAO();
        ArrayList<TeacherBean> teacherList=(ArrayList<TeacherBean>)(dao.selectAllTeacher()).clone();
        //将授课列表加入教师信息中
        ArrayList<TeacherBean> teacherCourseList=(ArrayList<TeacherBean>)(dao.selectCourseForTeacher(teacherList)).clone();
        //将单个teacher类中的courseList转换成String
        for (int i = 0; i < teacherCourseList.size(); i++) {
            String courseStr=String.join("、", (String[])teacherCourseList.get(i).getCourseList().toArray(new String[0]));
            teacherCourseList.get(i).setCourseStr(courseStr);
        }
        return teacherCourseList;
    }
}
