package com.qasystem.controller;

import com.qasystem.model.AttribBean;
import com.qasystem.model.TeachesBean;
import com.qasystem.model.TeachesDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AdminManTeachesServlet",urlPatterns = "/AdminManTeachesServlet")
public class AdminManTeachesServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String rid = request.getParameter("id");
        //返回全部授课记录
        if(rid!= null && rid.trim().equals("1")){
            TeachesBean teaches=new TeachesBean();
            TeachesDAO dao=new TeachesDAO();
            ArrayList<TeachesBean> teachesList=(ArrayList<TeachesBean>)(dao.selectAllTeaches().clone());
            AttribBean attrib25=new AttribBean();
            attrib25.setAdminSelectTeachesCheck(true);
            request.setAttribute("attrib25",attrib25);
            request.setAttribute("teachesList",teachesList);
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request,response);
        }
        else if(rid!= null && rid.trim().equals("2")){
            String tcid=request.getParameter("tcid");
            TeachesDAO dao=new TeachesDAO();
            boolean success=dao.deleteTeaches(tcid);


            //刷新全部课程信息
            TeachesBean teaches=new TeachesBean();
            ArrayList<TeachesBean> teachesList=(ArrayList<TeachesBean>)(dao.selectAllTeaches().clone());
            AttribBean attrib25=new AttribBean();
            attrib25.setAdminSelectTeachesCheck(true);
            request.setAttribute("attrib25",attrib25);
            request.setAttribute("teachesList",teachesList);
            RequestDispatcher rd=getServletContext().getRequestDispatcher("/adminPage.jsp");
            rd.forward(request,response);
        }
        else if(rid!= null && rid.trim().equals("3")){
            String tname=request.getParameter("tname1");
            String cname=request.getParameter("cname1");
            TeachesBean teaches=new TeachesBean();
            teaches.setTname(tname);
            teaches.setCname(cname);

            TeachesDAO dao=new TeachesDAO();

            //检查是否存在该授课记录
//            不存在，则执行添加指令
            if(!dao.ifTeachesExists(teaches)){
                dao.addTeaches(teaches);

                //刷新全部课程信息
                ArrayList<TeachesBean> teachesList2=(ArrayList<TeachesBean>)(dao.selectAllTeaches().clone());
                AttribBean attrib25=new AttribBean();
                attrib25.setAdminSelectTeachesCheck(true);
                request.setAttribute("attrib25",attrib25);
                request.setAttribute("teachesList",teachesList2);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request,response);
            }
            else{
                AttribBean attrib26=new AttribBean();
                attrib26.setAdminAddTeachesFail(true);
                request.setAttribute("attrib26",attrib26);

                //刷新全部课程信息
                ArrayList<TeachesBean> teachesList2=(ArrayList<TeachesBean>)(dao.selectAllTeaches().clone());
                AttribBean attrib25=new AttribBean();
                attrib25.setAdminSelectTeachesCheck(true);
                request.setAttribute("attrib25",attrib25);
                request.setAttribute("teachesList",teachesList2);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request,response);
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
