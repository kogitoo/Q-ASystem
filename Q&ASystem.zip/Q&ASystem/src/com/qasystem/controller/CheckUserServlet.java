package com.qasystem.controller;

import com.qasystem.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "CheckUserServlet",urlPatterns =  {"/CheckUserServlet"})
public class CheckUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        String option=request.getParameter("option");
        //验证学生身份
        if(option!=null && option.trim().equals("1")){
            //从request获取用户信息，封装成StudentBean
            StudentBean stu=new StudentBean(request.getParameter("name"),request.getParameter("password"));
            StudentDAO dao=new StudentDAO();
            if(dao.checkStudent(stu)){
                AttribBean attrib3=new AttribBean();
                attrib3.setStudentCheck(!true);
                HttpSession session=request.getSession();
                session.setAttribute("loginStudent", stu.getName());
                request.setAttribute("attrib3",attrib3);
                request.setAttribute("studentInfo",stu);

                //返回回答数
                session.setAttribute("stuAEQuestionImage",true);
                QuestionDAO qdao=new QuestionDAO();
                int stuAEQuestionTotal=qdao.stuGetAEQuestionNum(stu.getName());
                session.setAttribute("stuAEQuestionTotal",stuAEQuestionTotal);

                RequestDispatcher rd=getServletContext().getRequestDispatcher("/studentPage.jsp");
                rd.forward(request,response);
            }else{
                AttribBean attrib3=new AttribBean();
                attrib3.setStudentCheck(!false);
                request.setAttribute("attrib3",attrib3);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                rd.forward(request,response);
            }
        }
        //验证教师身份
        else if(option!=null && option.trim().equals("2")){
            //从request获取用户信息，封装成TeacherBean
            TeacherBean teacher=new TeacherBean(request.getParameter("name"),request.getParameter("password"));
            TeacherDAO dao=new TeacherDAO();
            if(dao.checkTeacher(teacher)){
                AttribBean attrib4=new AttribBean();
                attrib4.setTeacherCheck(!true);
                HttpSession session=request.getSession();
                session.setAttribute("loginTeacher", teacher.getName());
                request.setAttribute("attrib4",attrib4);
                request.setAttribute("teacherInfo",teacher);

                //返回新消息未读数
                //获取该教师所有授课信息
                TeacherBean newteacher=new TeacherBean();
                newteacher.setName(teacher.getName());
                ArrayList<TeacherBean> thisTeacher=new ArrayList<TeacherBean>();
                thisTeacher.add(newteacher);


                thisTeacher=dao.selectCourseForTeacher(thisTeacher);
                newteacher=thisTeacher.get(0);

                //获得全部课程中全部问题的问题列表
                ArrayList<QuestionBean> allQuestionList=new ArrayList<QuestionBean>();

                int newQuestionTotal=0;
                //遍历课程列表获得所有课程的所有问题
                QuestionDAO qdao=new QuestionDAO();
                for(int i=0;i<newteacher.getCourseList().size();i++){
                    int newQuestionNum=qdao.getNewQuestionNum(newteacher.getCourseList().get(i));
                    newQuestionTotal+=newQuestionNum;
                }

                session.setAttribute("newQuestionImage",true);
                session.setAttribute("newQuestionTotal", newQuestionTotal);

                RequestDispatcher rd=getServletContext().getRequestDispatcher("/teacherPage.jsp");
                rd.forward(request,response);
            }else{
                AttribBean attrib4=new AttribBean();
                attrib4.setTeacherCheck(!false);
                request.setAttribute("attrib4",attrib4);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                rd.forward(request,response);
            }
        }
        //验证管理员身份
        else if(option!=null && option.trim().equals("3")){
            //从request获取用户信息，封装成AdminBean
            AdminBean admin=new AdminBean(request.getParameter("name"),request.getParameter("password"));
            AdminDAO dao=new AdminDAO();
            if(dao.checkAdmin(admin)){
                AttribBean attrib5=new AttribBean();
                attrib5.setStudentCheck(!true);
                HttpSession session=request.getSession();
                session.setAttribute("loginAdmin", admin.getName());
                request.setAttribute("attrib5",attrib5);
                request.setAttribute("adminInfo",admin);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/adminPage.jsp");
                rd.forward(request,response);
            }else{
                AttribBean attrib5=new AttribBean();
                attrib5.setAdminCheck(!false);
                request.setAttribute("attrib5",attrib5);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                rd.forward(request,response);
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
