package com.qasystem.controller;

import com.qasystem.model.AttribBean;
import com.qasystem.model.StudentBean;
import com.qasystem.model.StudentDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "StuRegisterServlet",urlPatterns = {"/StuRegisterServlet"})
public class StuRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        try {
            //从request获取用户信息，封装成MSUserBean
            StudentBean stu=new StudentBean(request.getParameter("name"),request.getParameter("password"));
            StudentDAO dao=new StudentDAO();
            String option=request.getParameter("option");
            //验证是否是学生
            if(option!=null && option.trim().equals("1")){
                //将数据传至数据库
                if( stu.getName()!=null &&  stu.getPassword()!=null) {
                    //判断是否存在同名学生
                    //如果不存在，则注册成功
                    if(!dao.ifStudentExists(stu.getName())){
                        boolean success=dao.insertStudent(stu);
                        AttribBean attrib2=new AttribBean();
                        attrib2.setRegisterSuccess(success);
                        request.setAttribute("attrib2",attrib2);
                        RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                        rd.forward(request,response);
                    }
                    else{
                        AttribBean attrib27=new AttribBean();
                        attrib27.setStuRegisterFail(true);
                        request.setAttribute("attrib27",attrib27);
                        RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                        rd.forward(request,response);
                    }

                }
            }
            else{
                AttribBean attrib1=new AttribBean();
                attrib1.setNotStudent(true);
                request.setAttribute("attrib1",attrib1);
                RequestDispatcher rd=getServletContext().getRequestDispatcher("/login.jsp");
                rd.forward(request,response);
            }

        } catch(Exception e) {
            System.out.println(e.toString());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
